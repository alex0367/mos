/*
  This file exists for conformance with the
  SVR4 Application Binary Interface, which
  wants <rpc/rpc.h> in <rpc.h>.
*/
#include <rpc/rpc.h>
